# G-Mart (Grocery Mart)

![Screenshot 2024-08-03 134441](https://github.com/user-attachments/assets/f8684971-8bd4-466f-88d5-9b1ce81eadcb)



